🛡️ GUÍA DE RECUPERACIÓN - PLAN B SI ALGO SALE MAL

**Escrito:** 08/05/2026
**Para:** Implementación de v1.1 (Tareas 1-4)

---

## 🚨 ESCENARIOS DE ERROR Y SOLUCIONES

### ESCENARIO 1: El proyecto no compila (`npm run dev` da error)

#### Síntomas
```
npm run dev
→ Error: Unexpected token, Expected expression
→ Error en línea X de page.tsx o BookingCalendar.tsx
```

#### Solución (opción A - Rápida)

```bash
# 1. Revertir a respaldos v1.0
cp /home/claude/page.tsx.v1.0.RESPALDO src/app/page.tsx
cp /home/claude/BookingCalendar.tsx.v1.0.RESPALDO src/components/BookingCalendar.tsx

# 2. Limpiar cache
rm -rf .next
npm cache clean --force

# 3. Reinstalar dependencias (si es necesario)
npm install

# 4. Probar de nuevo
npm run dev

# 5. Si funciona: investigar línea por línea qué salió mal
```

#### Solución (opción B - Git)

```bash
# Si ya habías hecho commit con v1.1 y algo falla:

# 1. Ver histórico
git log --oneline

# 2. Volver al commit anterior (pre v1.1)
git revert HEAD
# O si quieres deshacer completamente:
git reset --hard <COMMIT_HASH_ANTERIOR>

# 3. Volver a las ramas de respaldo
git checkout backup/pre-tareas-prioritarias

# 4. Verificar que funciona
npm run dev
```

---

### ESCENARIO 2: Los botones del hero no hacen scroll

#### Síntomas
- Clickeas "Reservar Turno" → Nada pasa
- Clickeas "Ver Servicios" → Nada pasa
- Console muestra errores tipo: "Cannot read property 'scrollIntoView' of null"

#### Causa probable
- Faltan los `id` en las secciones, o
- Los `id` están mal escritos (typo), o
- El elemento está fuera del DOM

#### Solución

```bash
# 1. Verifica que los IDs estén correctos en page.tsx:

# Buscar "id="servicios"" (debe existir en la sección de servicios)
grep -n 'id="servicios"' src/app/page.tsx

# Buscar "id="reservas"" (debe existir en la sección de reservas)
grep -n 'id="reservas"' src/app/page.tsx

# 2. Si no aparecen, copiar desde page.tsx.v1.1:
cat /home/claude/page.tsx.v1.1 | grep -A 5 'id="servicios"'
cat /home/claude/page.tsx.v1.1 | grep -A 5 'id="reservas"'

# 3. Verificar que el onClick está bien escrito:
grep -A 5 'onClick={() => {' src/app/page.tsx

# 4. Si todo se ve bien, limpiar cache y recargar:
rm -rf .next
npm run dev

# 5. En navegador: F12 (abre DevTools) → Console
# Prueba hacer scroll manualmente:
document.getElementById("reservas").scrollIntoView({ behavior: "smooth" })
# Si funciona en console, es un problema de renderizado → npm run dev nuevamente
```

---

### ESCENARIO 3: Solo aparecen 3 barberos en lugar de 2

#### Síntomas
- Abrís la página → Todavía aparecen Kevin, Lucas, Franco
- Debería ser: solo 2 barberos (BARBERO_1, BARBERO_2)

#### Causa probable
- El archivo `BookingCalendar.tsx` no fue reemplazado correctamente
- Estás viendo la versión vieja v1.0

#### Solución

```bash
# 1. Verificar que estés usando la versión v1.1
grep -n "BARBERO_1" src/components/BookingCalendar.tsx

# Si NO aparece "BARBERO_1", entonces tienes v1.0:
cp /home/claude/BookingCalendar.tsx.v1.1 src/components/BookingCalendar.tsx

# 2. Limpiar cache y recargar
rm -rf .next
npm run dev

# 3. En navegador, hacer hard refresh: Ctrl+Shift+R (Windows) o Cmd+Shift+R (Mac)

# 4. Verificar console:
# Abre DevTools (F12) → Console
# Ejecuta: console.log("v1.1 check")
# Si ves el mensaje, el archivo se cargó correctamente
```

---

### ESCENARIO 4: El mensaje de WhatsApp sigue diciendo "gracias por reservar"

#### Síntomas
- Guardás una reserva
- El mensaje en WhatsApp dice: "Hola [nombre], gracias por reservar..."
- Debería decir: "Hola, soy [nombre]. Solicito una reserva para..."

#### Causa probable
- El archivo `BookingCalendar.tsx` no fue actualizado con Tarea 2
- Estás usando v1.0

#### Solución

```bash
# 1. Verificar el contenido del mensaje
grep -n "Solicito una reserva" src/components/BookingCalendar.tsx

# Si NO aparece, copiar desde v1.1:
cp /home/claude/BookingCalendar.tsx.v1.1 src/components/BookingCalendar.tsx

# 2. Limpiar cache
rm -rf .next
npm run dev

# 3. Probar nuevamente: crear una reserva de prueba
```

---

### ESCENARIO 5: Los barberos no tienen biografía, solo muestran placeholders

#### Síntomas
- Seleccionás una fecha
- Aparecen 2 tarjetas de barberos
- Pero dicen: "Tu minibio aquí. Cuéntanos tus especialidades..." (placeholder)
- Debería mostrar las bios reales

#### Solución RÁPIDA

```bash
# Esto es ESPERADO en v1.1 porque no tienes los datos reales aún
# Los campos tienen TODO: comments para que los completes luego

# Buscar los TODOs:
grep -n "TODO" src/components/BookingCalendar.tsx

# Verás líneas como:
# 16 |    nombre: "BARBERO_1", // TODO: Cambiar por nombre real
# 18 |    bio: "Tu minibio aquí...", // TODO: Reemplazar con biografía real

# Cuando tengas los datos reales, reemplazas esos valores
```

---

### ESCENARIO 6: En iOS, WhatsApp no se abre (sigue dando error)

#### Síntomas
- Testas en iPhone
- Guardás reserva
- WhatsApp no se abre
- Ves un mensaje de error o simplemente no pasa nada

#### Causa probable
- Problema con `window.location.href`
- La URL de WhatsApp está mal formada
- La app de WhatsApp no está instalada

#### Solución

```bash
# 1. Verificar que v1.1 está instalado
grep -n "window.location.href" src/components/BookingCalendar.tsx

# Debería ser (aproximadamente línea 131):
# window.location.href = `https://wa.me/59898914088?text=${mensaje}`;

# 2. Verificar que el número es correcto (59898914088)
grep -n "59898914088" src/components/BookingCalendar.tsx

# 3. Si ves "window.open", entonces tienes v1.0:
cp /home/claude/BookingCalendar.tsx.v1.1 src/components/BookingCalendar.tsx
npm run dev

# 4. En caso de que siga sin funcionar:
# - Verificar que WhatsApp está instalado en el iPhone
# - Intentar abrir WhatsApp manualmente y crear un chat de prueba
# - Probar el enlace en desktop primero
```

---

### ESCENARIO 7: Los horarios no se filtran según el barbero seleccionado

#### Síntomas
- Selecciono BARBERO_1 (franja mañana) → Siguen apareciendo todos los horarios (10:00-17:00)
- Debería mostrar solo: 10:00-13:00
- Selecciono BARBERO_2 (franja tarde) → Siguen apareciendo todos

#### Causa probable
- Versión v1.0 (sin filtro de horarios)
- La función `obtenerHorariosPorBarbero()` no se está ejecutando

#### Solución

```bash
# 1. Verificar que v1.1 está instalado
grep -n "obtenerHorariosPorBarbero" src/components/BookingCalendar.tsx

# Debería aparecer la función (alrededor de línea 57-70)

# 2. Si no aparece, copiar v1.1:
cp /home/claude/BookingCalendar.tsx.v1.1 src/components/BookingCalendar.tsx

# 3. Limpiar cache y recargar
rm -rf .next
npm run dev

# 4. Probar: selecciona fecha → BARBERO_1 → verifica que aparezcan solo horarios de mañana
```

---

## 🔄 FLUJO DE RECUPERACIÓN GENERAL (PASO A PASO)

Si algo está roto y no sabés qué pasó:

```bash
# PASO 1: Ver estado actual
git status
# → Si hay archivos modificados sin guardar, git los listará

# PASO 2: Identificar qué está roto
npm run dev
# → Anotá el error exacto

# PASO 3: Volver a estado conocido (v1.0)
cp /home/claude/page.tsx.v1.0.RESPALDO src/app/page.tsx
cp /home/claude/BookingCalendar.tsx.v1.0.RESPALDO src/components/BookingCalendar.tsx
rm -rf .next
npm run dev

# PASO 4: Verificar que v1.0 funciona
# → Si funciona, el problema está en v1.1

# PASO 5: Reaplicar v1.1 con cuidado
cp /home/claude/page.tsx.v1.1 src/app/page.tsx
rm -rf .next
npm run dev
# → Verifica que funciona

cp /home/claude/BookingCalendar.tsx.v1.1 src/components/BookingCalendar.tsx
rm -rf .next
npm run dev
# → Verifica que funciona

# PASO 6: Si algo sigue roto
# → Contacta con Claude o abre issue en GitHub
# → Adjunta el error exacto + captura de pantalla
```

---

## 🔗 COMANDOS ÚTILES

```bash
# Ver qué versión de archivo tenés instalada
head -20 src/app/page.tsx | grep -i "onClick\|id="

# Comparar tu archivo actual con v1.1
diff src/app/page.tsx /home/claude/page.tsx.v1.1

# Restaurar un archivo específico
git checkout -- src/app/page.tsx

# Ver histórico de cambios
git log --oneline src/app/page.tsx

# Limpiar todo y empezar de nuevo
rm -rf .next node_modules package-lock.json
npm install
npm run dev
```

---

## 📞 CONTACTO EN CASO DE EMERGENCIA

Si nada de esto funciona:

1. **Toma una captura de pantalla del error**
2. **Copia el mensaje de error completo**
3. **Ejecuta:**
   ```bash
   npm --version
   node --version
   # Comparte estas versiones
   ```
4. **Comparte:**
   - Mensaje de error exacto
   - Archivo que da error (page.tsx o BookingCalendar.tsx)
   - Resultado de `git log --oneline -5`
5. **Abre una conversación nueva con Claude** y adjunta:
   - Este documento (RECUPERACIÓN.md)
   - El archivo con error (en txt)
   - El Documento Maestro v1.1
