📄 DOCUMENTO MAESTRO DEL PROYECTO "BANBAN" - APP DE RESERVAS PARA BARBERÍA

Versión: 1.1 (EN PROGRESO - Tareas 1-4 Implementadas)
Fecha: 08/05/2026
Propósito: Servir como fuente única de verdad para todas las IAs que colaboren en el desarrollo.
Metodología de trabajo: Colaboración asíncrona entre distintas IAs, con un humano como integrador y "router" de contexto.

---

## 🗂️ 1. ESTRUCTURA DEL PROYECTO (RUTAS WINDOWS)

**Ruta raíz:** `C:\Proyectos\temapelu\deepseek\banban-app`

### Archivos principales (código fuente)

| Ruta completa | Propósito | Estado v1.1 |
|---|---|---|
| `src\app\layout.tsx` | Layout raíz de Next.js | ✅ Sin cambios |
| `src\app\globals.css` | Estilos globales con Tailwind CSS | ✅ Sin cambios |
| `src\app\page.tsx` | Página principal (Home) | ✅ MODIFICADO - Tarea 1 aplicada |
| `src\components\BookingCalendar.tsx` | Componente de reservas | ✅ MODIFICADO - Tareas 2, 3, 4 aplicadas |
| `src\lib\supabase.ts` | Cliente de Supabase | ✅ Sin cambios |

### Archivos que NO existen (planeados para próximas versiones)

- `src/app/admin/page.tsx` — Panel de administración (v1.2)
- `src/app/cancelar/page.tsx` — Página de cancelación (v1.2)
- `src/app/contacto/page.tsx` — Formulario de contacto (v1.2)

### Archivos obsoletos (PUEDEN ELIMINARSE)

- `src/components/BookingCalendar - copia.tsx`
- `src/components/BookingCalendar - copia (2).tsx`
- `src/components/BookingCalendar - copia (3).tsx`
- `src/components/BookingCalendar - copia (4).tsx`

---

## 📊 2. ESTADO ACTUAL (v1.1)

### ✅ Lo que funciona correctamente (v1.0 + v1.1)

- Página principal carga con navbar, hero, video, servicios y reservas
- Calendario (DayPicker) valida fechas futuras en UTC
- Selección progresiva: fecha → barbero → nombre/teléfono → horario
- Disponibilidad en tiempo real desde Supabase
- Reservas se guardan en tabla `reservas` de Supabase
- WhatsApp Web se abre correctamente en desktop y móvil (ahora con `window.location.href`)
- Proyecto desplegado en Vercel (URL: https://ban-ban-app.vercel.app)
- Auto-actualización en Vercel al hacer `git push` a `main`

### 🆕 Lo que se agregó en v1.1 (TAREAS 1-4 COMPLETADAS)

#### ✅ TAREA 1: Arreglar botones del hero
- **Cambio:** Agregué `onClick` handlers a ambos botones
- **Función:** Scroll suave (`behavior: "smooth"`) a secciones
- **Detalles:**
  - Botón "Reservar Turno" → Scroll a `id="reservas"`
  - Botón "Ver Servicios" → Scroll a `id="servicios"`
  - Agregué los `id` a las secciones correspondientes
  - Validación: verifica que el elemento existe antes de hacer scroll
- **Archivo:** `src\app\page.tsx` (líneas ~40, ~47, ~108, ~174)

#### ✅ TAREA 2: Mensaje WhatsApp claro
- **Cambio:** Nuevo formato de mensaje
- **Anterior:** "Hola [nombre], gracias por reservar..." (suena como confirmación)
- **Ahora:** "Hola, soy [nombre]. Solicito una reserva para el [fecha]..." (solicitud clara)
- **Archivo:** `src\components\BookingCalendar.tsx` (línea ~130)

#### ✅ TAREA 3: iOS + WhatsApp compatible
- **Cambio:** Reemplacé `window.open()` por `window.location.href`
- **Razón:** Safari en iOS bloquea `window.open()`, pero permite `window.location.href`
- **Beneficio:** Funciona en iOS, Android y desktop
- **Archivo:** `src\components\BookingCalendar.tsx` (línea ~131)

#### ✅ TAREA 4: Ajustar barberos (2 + franjas + bio)
- **Cambio 1:** Reducir de 3 a 2 barberos
- **Cambio 2:** Reemplazar campo `estilo` por `bio` (2-3 líneas)
- **Cambio 3:** Agregar campo `franja` ("mañana" o "tarde")
- **Cambio 4:** Filtrar horarios según franja seleccionada
- **Detalles:**
  - BARBERO_1 (placeholder): franja "mañana" (10:00-13:00)
  - BARBERO_2 (placeholder): franja "tarde" (14:00-17:00)
  - Grid de barberos cambia a 2 columnas (antes 3)
  - Bio se muestra con saltos de línea (`whitespace-pre-line`)
  - Indicador visual: 🌅 (mañana) o 🌆 (tarde)
  - Al cambiar barbero, se resetea la hora seleccionada
  - Función `obtenerHorariosPorBarbero()` filtra los 14 horarios disponibles
- **Archivo:** `src\components\BookingCalendar.tsx` (líneas ~13-40, ~57-70, ~178-181)

### ⚠️ PENDIENTE: Completar valores reales

Los siguientes campos tienen **placeholders** que deben reemplazarse cuando tengas la información:

| Campo | Ubicación | Placeholder actual | Valor real | Estado |
|-------|-----------|-------------------|-----------|--------|
| Nombre Barbero 1 | `BookingCalendar.tsx:16` | `BARBERO_1` | ??? | ⏳ Pendiente |
| Bio Barbero 1 | `BookingCalendar.tsx:18` | "Tu minibio aquí..." | ??? | ⏳ Pendiente |
| Foto Barbero 1 | `BookingCalendar.tsx:20` | Placeholder URL | ??? | ⏳ Pendiente |
| Nombre Barbero 2 | `BookingCalendar.tsx:25` | `BARBERO_2` | ??? | ⏳ Pendiente |
| Bio Barbero 2 | `BookingCalendar.tsx:27` | "Tu minibio aquí..." | ??? | ⏳ Pendiente |
| Foto Barbero 2 | `BookingCalendar.tsx:29` | Placeholder URL | ??? | ⏳ Pendiente |
| Nombre de la barbería | `page.tsx` (navbar) | "BANBAN" | ??? | ⏳ Pendiente |

### ❌ Lo que AÚN NO funciona (para próximas versiones)

- Panel de administración real (ruta `/admin`) — **v1.2**
- Página de cancelación para clientes (ruta `/cancelar`) — **v1.2**
- Formulario de contacto funcional (ruta `/contacto`) — **v1.2**
- Columna de estado en Supabase (pendiente, confirmada, cancelada) — **v1.3**
- Notificaciones por email/SMS — **v1.3**

---

## 🧪 3. CÓMO PROBAR EN LOCAL (v1.1)

```bash
# 1. Copiar los archivos v1.1 a tu proyecto
#    - Reemplaza src\app\page.tsx con page.tsx.v1.1
#    - Reemplaza src\components\BookingCalendar.tsx con BookingCalendar.tsx.v1.1

# 2. Verificar que .env.local esté configurado
#    - NEXT_PUBLIC_SUPABASE_URL
#    - NEXT_PUBLIC_SUPABASE_ANON_KEY

# 3. Ejecutar en desarrollo
npm run dev

# 4. Abrir en navegador
# http://localhost:3000

# 5. PRUEBAS MANUALES:
# ✅ Clickear botón "Reservar Turno" → debe hacer scroll suave a #reservas
# ✅ Clickear botón "Ver Servicios" → debe hacer scroll suave a #servicios
# ✅ Seleccionar fecha → deben aparecer 2 tarjetas de barberos (no 3)
# ✅ Cada tarjeta debe mostrar bio en lugar de "estilo"
# ✅ Cada tarjeta debe indicar franja horaria (🌅 mañana / 🌆 tarde)
# ✅ Seleccionar Barbero 1 → horarios disponibles: 10:00-13:00
# ✅ Seleccionar Barbero 2 → horarios disponibles: 14:00-17:00
# ✅ Guardar reserva → mensaje WhatsApp debe ser una SOLICITUD (no "gracias por")
# ✅ En iOS: window.location.href permite abrir WhatsApp (sin bloqueo)
```

---

## 🔄 4. DECISIONES TÉCNICAS (REVISADAS EN v1.1)

| Decisión | Justificación | Cambios en v1.1 |
|----------|---------------|-----------------|
| DayPicker como calendario | Buena UX, personalizable | ✅ Sin cambios |
| Formato ISO para fechas | Evita problemas de zona horaria | ✅ Sin cambios |
| Horarios fijos (10:00-17:00) | Simplifica lógica | ✅ SIN CAMBIOS - Se mantienen los 14 intervalos de 30 min |
| WhatsApp desde cliente | No requiere API paga | ✅ MEJORADO - Ahora usa `window.location.href` para iOS |
| 2 barberos con franjas | Refleja estructura real | ✅ NUEVO - Se implementó en Tarea 4 |
| Cancelación por admin (panel) | Evita complejidad inicial | ✅ Sin cambios - Pendiente para v1.2 |

---

## 📋 5. TAREAS PENDIENTES (REVISADAS v1.1)

### ✅ COMPLETADAS EN v1.1

- [x] Arreglar botones del hero (Tarea 1)
- [x] Mensaje WhatsApp claro (Tarea 2)
- [x] iOS + WhatsApp (Tarea 3)
- [x] Ajustar barberos (Tarea 4)

### 🟡 PRIORIDAD MEDIA (v1.2)

- [ ] Crear panel de administración real (`/admin`)
  - Login simple (contraseña en .env)
  - Tabla de reservas (fecha, hora, barbero, nombre, teléfono)
  - Acciones: Cancelar, Confirmar
  - Diseño responsivo

- [ ] Formulario de contacto funcional
  - Ruta `/contacto`
  - Campos: nombre, email, teléfono, mensaje
  - Envío via Resend o EmailJS
  - Email a dirección del dueño

- [ ] Página de cancelación para clientes
  - Opción: ingresar teléfono, listar reservas, cancelar
  - Requiere autenticación por código SMS (opcional)

### 🟢 PRIORIDAD BAJA (v1.3+)

- [ ] Eliminar archivos "Copia" de src/components
- [ ] Mejorar responsividad del DayPicker en móvil
- [ ] Agregar columna `estado` en Supabase (pendiente, confirmada, cancelada)
- [ ] Sistema de notificaciones (email/SMS)
- [ ] Panel de estadísticas para barbería

---

## 🛡️ 6. RESPALDOS Y RECUPERACIÓN

### Archivos de respaldo creados (v1.0)

```
/home/claude/
├── page.tsx.v1.0.RESPALDO
├── BookingCalendar.tsx.v1.0.RESPALDO
├── page.tsx.v1.1
└── BookingCalendar.tsx.v1.1
```

### Rama de respaldo en Git

```bash
# Crear rama de respaldo ANTES de implementar v1.1
git checkout -b backup/pre-tareas-prioritarias
git push origin backup/pre-tareas-prioritarias

# Si algo sale mal, volver a respaldo
git checkout backup/pre-tareas-prioritarias
```

---

## 📝 7. INSTRUCCIONES PARA OTROS DEVS

Al recibir este documento (v1.1 o posterior):

1. Lee todo el documento antes de proponer cambios
2. Verifica la lista de "Pendiente: Completar valores reales" (tabla)
3. Si necesitas ver código actual, pide el archivo específico
4. Documenta cualquier nueva decisión para la próxima versión
5. No hagas cambios sin actualizar este documento

---

## 🔐 8. CREDENCIALES (NO COMPARTIR)

- Número WhatsApp: 59898914088
- URL Vercel: https://ban-ban-app.vercel.app
- Variables .env: Ver .env.local (NO SUBIR A GITHUB)

---

## 📌 PRÓXIMOS PASOS

1. **Ahora:** Probar v1.1 en local (`npm run dev`)
2. **Si funciona:** Git commit + push a rama `develop`
3. **Cuando tengas datos reales:** Abrir nueva conversación con Claude/otro dev, compartir este documento + tabla de valores
4. **v1.2:** Implementar panel admin
5. **v1.3+:** Contacto, notificaciones, estadísticas
