📋 CHANGELOG - PROYECTO BANBAN

## v1.1 (08/05/2026) - Tareas 1-4 Implementadas

### Cambios por archivo

#### `src/app/page.tsx`

**TAREA 1: Arreglar botones del hero**

- Agregué `onClick` handler al botón "Reservar Turno"
  - Ejecuta: `document.getElementById("reservas").scrollIntoView({ behavior: "smooth" })`
  - Manejo de error: verifica que el elemento existe

- Agregué `onClick` handler al botón "Ver Servicios"
  - Ejecuta: `document.getElementById("servicios").scrollIntoView({ behavior: "smooth" })`
  - Manejo de error: verifica que el elemento existe

- Agregué `id="servicios"` a la sección de servicios
  - Línea ~108

- Agregué `id="reservas"` a la sección de reservas
  - Línea ~174

**Código antes:**
```jsx
<button className="px-10 py-5 rounded-full bg-yellow-600...">
  Reservar Turno
</button>

<button className="px-10 py-5 rounded-full border...">
  Ver Servicios
</button>
```

**Código después:**
```jsx
<button 
  onClick={() => {
    const element = document.getElementById("reservas");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  }}
  className="px-10 py-5 rounded-full bg-yellow-600..."
>
  Reservar Turno
</button>

<button 
  onClick={() => {
    const element = document.getElementById("servicios");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  }}
  className="px-10 py-5 rounded-full border..."
>
  Ver Servicios
</button>
```

---

#### `src/components/BookingCalendar.tsx`

**TAREA 2: Mensaje WhatsApp claro**

- Cambié el formato del mensaje de WhatsApp
- Es claramente una SOLICITUD, no una confirmación

**Código antes:**
```typescript
const mensaje = encodeURIComponent(
  `Hola ${nombre.trim()}, gracias por reservar.\n\n📅 Fecha: ${selected.toLocaleDateString()}\n⏰ Hora: ${hora}\n✂️ Barbero: ${barbero}\n📞 Teléfono: ${telefono.trim()}`
);
```

**Código después:**
```typescript
const mensaje = encodeURIComponent(
  `Hola, soy ${nombre.trim()}. Solicito una reserva para el ${selected.toLocaleDateString()} a las ${hora} con ${barbero}. Mi teléfono es ${telefono.trim()}. Quedo a la espera de su confirmación.`
);
```

**Beneficio:** El cliente entiende que debe esperar confirmación de la barbería.

---

**TAREA 3: iOS + WhatsApp compatible**

- Reemplacé `window.open()` por `window.location.href`
- Mejora compatibilidad con iOS (Safari no bloquea `window.location.href`)

**Código antes:**
```typescript
window.open(`https://wa.me/59898914088?text=${mensaje}`, "_blank");
alert("Reserva guardada correctamente.");
```

**Código después:**
```typescript
window.location.href = `https://wa.me/59898914088?text=${mensaje}`;
alert("Reserva guardada. Se abrirá WhatsApp para confirmar.");
```

**Beneficio:** Funciona en iOS, Android y desktop.

---

**TAREA 4: Ajustar barberos (2 + franjas + bio)**

**Cambio 1: Estructura de datos**

- Reemplacé array de 3 barberos por 2 barberos con nuevos campos
- Eliminé campo `estilo`, agregué campos `bio` y `franja`

**Código antes:**
```typescript
const barberos = [
  { nombre: "Kevin", estilo: "Fade Expert", foto: "https://..." },
  { nombre: "Lucas", estilo: "Beard Specialist", foto: "https://..." },
  { nombre: "Franco", estilo: "Urban Style", foto: "https://..." },
];
```

**Código después:**
```typescript
const barberos = [
  { 
    nombre: "BARBERO_1", // TODO: Cambiar por nombre real
    bio: "Tu minibio aquí.\nCuéntanos tus especialidades.\nDos o tres líneas.", // TODO: Reemplazar
    foto: "https://...", // TODO: Cambiar por foto real
    franja: "mañana" // 10:00 a 13:00
  },
  { 
    nombre: "BARBERO_2", // TODO: Cambiar por nombre real
    bio: "Tu minibio aquí.\nCuéntanos tus especialidades.\nDos o tres líneas.", // TODO: Reemplazar
    foto: "https://...", // TODO: Cambiar por foto real
    franja: "tarde" // 14:00 a 17:00
  },
];
```

---

**Cambio 2: Horarios disponibles**

- Agregué array completo de 14 horarios (con intervalos de 30 min)
- Creé función `obtenerHorariosPorBarbero()` que filtra según franja

**Código nuevo:**
```typescript
const horariosCompletos = [
  "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00",
  "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00"
];

const obtenerHorariosPorBarbero = (nombreBarbero: string) => {
  const barberoObj = barberos.find(b => b.nombre === nombreBarbero);
  if (!barberoObj) return [];

  if (barberoObj.franja === "mañana") {
    return horariosCompletos.filter(h => {
      const [horas, minutos] = h.split(":").map(Number);
      const totalMinutos = horas * 60 + minutos;
      return totalMinutos <= 13 * 60; // Hasta las 13:00
    });
  } else if (barberoObj.franja === "tarde") {
    return horariosCompletos.filter(h => {
      const [horas, minutos] = h.split(":").map(Number);
      const totalMinutos = horas * 60 + minutos;
      return totalMinutos >= 14 * 60; // Desde las 14:00
    });
  }
  return [];
};
```

---

**Cambio 3: Resetear hora al cambiar barbero**

- Agregué `useEffect` que resetea `hora` cuando cambia `barbero`
- Esto es necesario porque los horarios disponibles son diferentes para cada barbero

**Código nuevo:**
```typescript
useEffect(() => {
  setHora("");
}, [barbero]);
```

---

**Cambio 4: Grid de barberos (3 → 2 columnas)**

**Código antes:**
```jsx
<div className="grid md:grid-cols-3 gap-6">
```

**Código después:**
```jsx
<div className="grid md:grid-cols-2 gap-6">
```

---

**Cambio 5: Mostrar bio en lugar de estilo**

**Código antes:**
```jsx
<h3 className="text-2xl font-bold">{b.nombre}</h3>
<p className="text-zinc-400 mt-2">{b.estilo}</p>
```

**Código después:**
```jsx
<h3 className="text-2xl font-bold">{b.nombre}</h3>
<p className="text-zinc-400 mt-3 text-sm leading-relaxed whitespace-pre-line">
  {b.bio}
</p>
<p className="text-yellow-500 text-xs mt-3 font-semibold">
  {b.franja === "mañana" ? "🌅 Turnos mañana" : "🌆 Turnos tarde"}
</p>
```

**Beneficio:**
- Bio se muestra con saltos de línea (`whitespace-pre-line`)
- Indicador visual de franja horaria (emoji)

---

**Cambio 6: Usar horarios filtrados en sección de horarios**

**Código nuevo:**
```typescript
const horariosDisponibles = barbero ? obtenerHorariosPorBarbero(barbero) : [];

// Luego en el render:
{horariosDisponibles.map((h) => {
  // ... mostrar solo los horarios disponibles para ese barbero
})}
```

---

### Resumen de cambios

| Archivo | Tareas | Cambios | Estado |
|---------|--------|---------|--------|
| `page.tsx` | 1 | 3 (scroll handlers + 2 IDs) | ✅ Completado |
| `BookingCalendar.tsx` | 2, 3, 4 | 12 (mensaje, window.location.href, barberos, horarios) | ✅ Completado |

---

## v1.0 (Baseline)

Estado inicial del proyecto con:
- Calendario funcional
- 3 barberos
- Reservas guardadas en Supabase
- WhatsApp con `window.open()`
- Botones del hero sin funcionalidad
